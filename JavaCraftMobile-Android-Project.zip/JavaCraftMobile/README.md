# JavaCraft Mobile

A custom Android launcher **prototype** for Minecraft Java Edition.

## What this project currently does
- Provides a custom Android launcher interface.
- Lets you select a Minecraft version and a mod-loader preference.
- Provides placeholder RAM, touch, controller, shader, and performance preferences.
- Opens the Amethyst Android releases page as the suggested compatible Java runtime.

## Important: current limitations
This project is a launcher UI prototype, **not yet a functioning Minecraft Java launcher**. The Play button deliberately explains that the game engine is not integrated. The version and loader selectors are UI preferences only; they do not download or install Minecraft, Forge, Fabric, mods, or shaders.

A real Java launcher needs a compatible Java runtime, Minecraft asset/library/version downloading, Microsoft account authentication, native game libraries, graphics translation, input mapping, and engine integration. Those pieces must be integrated and tested before claiming that Play works.

## Build without a PC
This repository includes a GitHub Actions workflow:
1. Create a GitHub repository in your phone browser.
2. Upload the contents of this project to the repository (keep the `.github/workflows/build.yml` path).
3. Open the repository's **Actions** tab.
4. Run **Build JavaCraft APK** (or push to `main`).
5. Open the completed workflow run and download the `JavaCraft-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow installs from your browser or file manager.

You can also open the repository in an Android IDE that supports Gradle projects and build the debug APK locally.

## Suggested engine
Amethyst Android: https://github.com/AngelAuraMC/Amethyst-Android

Use a legitimate Minecraft Java Edition account. Follow the engine project's own installation and account-authentication instructions.
