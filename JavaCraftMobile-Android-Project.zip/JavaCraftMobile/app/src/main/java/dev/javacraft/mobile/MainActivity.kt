package dev.javacraft.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 24, 20)
    private val panel = Color.rgb(31, 43, 35)
    private val green = Color.rgb(103, 190, 115)
    private val white = Color.rgb(242, 246, 241)
    private val muted = Color.rgb(177, 191, 180)

    private lateinit var version: Spinner
    private lateinit var loader: Spinner
    private lateinit var ram: SeekBar
    private lateinit var ramLabel: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildHome()
    }

    private fun buildHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("JAVACRAFT", 27f, green, true))
        page.addView(label("MINECRAFT JAVA • ANDROID LAUNCHER", 11f, muted, true).apply {
            setPadding(0, dp(3), 0, dp(20))
        })

        val hero = card()
        hero.addView(label("Your worlds. Your rules.", 23f, white, true))
        hero.addView(label("A custom launcher interface for Android.", 13f, muted, false))
        hero.addView(label("ENGINE STATUS: NOT CONNECTED", 11f, green, true).apply {
            setPadding(0, dp(15), 0, 0)
        })
        page.addView(hero)

        page.addView(section("GAME VERSION"))
        version = Spinner(this).apply {
            adapter = spinnerAdapter(listOf("1.21.4", "1.21.1", "1.20.1", "1.19.4", "1.18.2", "1.16.5"))
        }
        page.addView(fieldContainer(version))

        page.addView(section("MOD LOADER"))
        loader = Spinner(this).apply {
            adapter = spinnerAdapter(listOf("Vanilla", "Fabric", "Forge", "NeoForge", "Quilt"))
        }
        page.addView(fieldContainer(loader))

        page.addView(section("PERFORMANCE"))
        val perf = card()
        ramLabel = label("RAM allocation: 3 GB", 15f, white, true)
        perf.addView(ramLabel)
        ram = SeekBar(this).apply {
            max = 7
            progress = 2
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            thumbTintList = android.content.res.ColorStateList.valueOf(green)
        }
        ram.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                ramLabel.text = "RAM allocation: ${p + 1} GB (preference only)"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        perf.addView(ram)
        perf.addView(label("Actual safe memory limits depend on your phone and Android.", 11f, muted, false))
        page.addView(perf)

        page.addView(section("EXTRAS"))
        val extras = card()
        extras.addView(toggle("Touchscreen controls", true))
        extras.addView(toggle("Controller support", true))
        extras.addView(toggle("Shader support", true))
        extras.addView(toggle("Performance optimizations", true))
        extras.addView(label("These are planned launcher preferences; they do not activate game features until a compatible engine is connected.", 11f, muted, false))
        page.addView(extras)

        val play = Button(this).apply {
            text = "CONNECT JAVA ENGINE"
            setTextColor(Color.rgb(10, 25, 13))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            textSize = 15f
            setOnClickListener { openEnginePage() }
        }
        val playParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(20) }
        page.addView(play, playParams)

        val launch = Button(this).apply {
            text = "PLAY MINECRAFT"
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener {
                status.text = "Minecraft cannot launch yet: the Java game engine is not integrated. Install/connect a compatible engine first."
                status.visibility = View.VISIBLE
            }
        }
        page.addView(launch, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })

        status = label("", 12f, green, false).apply {
            visibility = View.GONE
            setPadding(dp(4), dp(12), dp(4), 0)
        }
        page.addView(status)

        page.addView(label("JavaCraft Mobile 0.1.0 • Prototype", 11f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(25), 0, 0)
        })
    }

    private fun openEnginePage() {
        val uri = Uri.parse("https://github.com/AngelAuraMC/Amethyst-Android/releases")
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(16).toFloat()
        }
    }

    private fun section(s: String): TextView = label(s, 12f, green, true).apply {
        setPadding(dp(2), dp(22), 0, dp(8))
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun fieldContainer(v: View): LinearLayout = LinearLayout(this).apply {
        setPadding(dp(8), dp(3), dp(8), dp(3))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(12).toFloat()
        }
        addView(v, LinearLayout.LayoutParams(-1, dp(48)))
    }

    private fun spinnerAdapter(items: List<String>): ArrayAdapter<String> =
        ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun toggle(name: String, checked: Boolean): View {
        return CheckBox(this).apply {
            text = name
            isChecked = checked
            setTextColor(white)
            buttonTintList = android.content.res.ColorStateList.valueOf(green)
            textSize = 14f
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
